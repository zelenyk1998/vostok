import React, { useContext, useEffect, useState } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { useTranslation } from "react-i18next";
import { Pressable, Text, StyleSheet } from "react-native";
import {
  AuthenticationScreen,
  ConfimResetPassScreen,
  HomeScreen,
  InputOTPScreen,
  LoginScreen,
  ProfileScreen,
  RestoreScreen,
  SettingScreen,
  HistoryScreen,
  PartnersScreen,
  RefillScreen,
  CardScreen,
} from "./src/screens/index";
import Preloader from "./src/ui/Preloader";
import AuthContextProvider, { AuthContext } from "./src/store/auth-context";
import IconButton from "./src/ui/IconButton";
import "./src/localization/i18n";

const Stack = createNativeStackNavigator();

const AuthStackScreenOptions = (t, changeLanguage, selectedLanguage) => {
  return {
    title: t("screens.LoginPage"),
    headerStyle: {
      backgroundColor: "#DFFF00",
    },
    headerTintColor: "#0FFF50",
    headerRight: () => (
      <>
        <Pressable
          style={({ pressed }) => [
            styles.btnEng,
            selectedLanguage === "en" && styles.selected,
            pressed && styles.pressed,
          ]}
          onPress={() => changeLanguage("en")}
        >
          <Text style={styles.lng}>{"Eng"}</Text>
        </Pressable>
        <Pressable
          style={({ pressed }) => [
            styles.btnUk,
            selectedLanguage === "uk" && styles.selected,
            pressed && styles.pressed,
          ]}
          onPress={() => changeLanguage("uk")}
        >
          <Text style={styles.lng}>{"Uk"}</Text>
        </Pressable>
      </>
    ),
  };
};

const AuthStack = () => {
  const { t, i18n } = useTranslation();
  const [selectedLanguage, setSelectedLanguage] = useState("uk");

  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
    setSelectedLanguage(lng);
  };

  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Login"
        component={LoginScreen}
        options={AuthStackScreenOptions(t, changeLanguage, selectedLanguage)}
      />
      <Stack.Screen
        name="Authentication"
        component={AuthenticationScreen}
        options={{
          title: t("screens.AuthPage"),
          headerStyle: {
            backgroundColor: "#008080",
          },
          headerTintColor: "#fff",
        }}
      />
      <Stack.Screen
        name="Restore"
        component={RestoreScreen}
        options={{
          title: t("screens.RestorePage"),
          headerStyle: {
            backgroundColor: "#008080",
          },
          headerTintColor: "#fff",
        }}
      />
      <Stack.Screen
        name="InputOTP"
        component={InputOTPScreen}
        options={{
          title: t("screens.ConfirmPage"),
          headerStyle: {
            backgroundColor: "#008080",
          },
          headerTintColor: "#fff",
        }}
      />
      <Stack.Screen
        name="ConfirmReset"
        component={ConfimResetPassScreen}
        options={{
          title: t("screens.ConfirmPage"),
          headerStyle: {
            backgroundColor: "#008080",
          },
          headerTintColor: "#fff",
        }}
      />
    </Stack.Navigator>
  );
};

const Navigation = () => {
  const authCtx = useContext(AuthContext);
  const Drawer = createDrawerNavigator();
  const { t } = useTranslation();

  return (
    <NavigationContainer>
      {!authCtx.isAuthenticated && <AuthStack />}
      {authCtx.isAuthenticated && (
        <Drawer.Navigator
          screenOptions={{
            drawerStyle: {
              backgroundColor: "#F0E68C",
              width: 200,
            },
          }}
        >
          <Drawer.Screen
            name="Home"
            component={HomeScreen}
            options={{
              title: t("screens.HomePage"),
              headerStyle: {
                backgroundColor: "white",
              },
              headerTintColor: "black",
              headerRight: () => (
                <Pressable style={({ pressed }) => [styles.logoutButton]}>
                  <Text onPress={authCtx.logout} style={styles.logoutText}>
                    LogOut
                  </Text>
                </Pressable>
              ),
            }}
          />
          <Drawer.Screen
            name="Profile"
            component={ProfileScreen}
            options={{
              title: "",
              headerShown: true,
              drawerLabel: t("screens.ProfilePage"),
            }}
          />
          <Drawer.Screen
            name="Card"
            component={CardScreen}
            options={{
              title: "",
              headerShown: true,
              drawerLabel: t("screens.CardPage"),
            }}
          />
          <Drawer.Screen
            name="Settings"
            component={SettingScreen}
            options={{
              title: "",
              headerShown: true,
              drawerLabel: t("screens.SettingPage"),
            }}
          />
          <Drawer.Screen
            name="History"
            component={HistoryScreen}
            options={{
              title: "",
              headerShown: true,
              drawerLabel: t("screens.HistoryPage"),
            }}
          />
          <Drawer.Screen
            name="Partners"
            component={PartnersScreen}
            options={{
              title: "",
              headerShown: true,
              drawerLabel: t("screens.PartnersPage"),
            }}
          />
          <Drawer.Screen
            name="Refill"
            component={RefillScreen}
            options={{
              title: "",
              headerShown: true,
              drawerLabel: t("screens.RefillPage"),
            }}
          />
        </Drawer.Navigator>
      )}
    </NavigationContainer>
  );
};

const Root = () => {
  const authCtx = useContext(AuthContext);
  const [isLoading, setIsLoading] = useState(true);
  const fetchToken = () =>
    authCtx.login().then((storedToken) => {
      setIsLoading(false);

      return authCtx.authenticate(storedToken || "");
    });

  useEffect(() => {
    fetchToken();
  }, []);

  if (isLoading) return <Preloader />;

  return <Navigation />;
};

const App = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setIsLoading(false);
    }, 2000);
  }, []);

  if (isLoading) {
    return <Preloader />;
  }

  return (
    <>
      <AuthContextProvider>
        <Root />
      </AuthContextProvider>
    </>
  );
};

export default App;

const styles = StyleSheet.create({
  pressed: {
    opacity: 0.7,
  },
  btnEng: {
    alignItems: "center",
    width: 50,
    borderRadius: 10,
    backgroundColor: "white",
    justifyContent: "center",
    marginRight: 10,
    borderColor: "#FF10F0",
    borderWidth: 0.75,
  },
  btnUk: {
    width: 50,
    borderRadius: 10,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 10,
    borderColor: "#FF10F0",
    borderWidth: 0.75,
  },
  selected: {
    backgroundColor: "#AAFF00",
    borderWidth: 0.75,
    borderColor: "white",
  },
  lng: {
    textAlign: "auto",
    padding: 6,
    color: "black",
  },
  iconHeader: {
    marginRight: 20,
    flexDirection: "row",
  },
  iconNews: {
    marginLeft: 10,
  },
  iconNotification: {
    marginRight: 10,
  },
  logoutButton: {
    width: 80,
    height: 35,
    borderRadius: 15,
    backgroundColor: "white",
    justifyContent: "center",
    marginRight: 10,
    borderColor: "#FF10F0",
    borderWidth: 0.75,
    backgroundColor: "#8B4513",
  },
  logoutText: {
    color: "white",
    fontSize: 20,
    textAlign: "center",
  },
});
