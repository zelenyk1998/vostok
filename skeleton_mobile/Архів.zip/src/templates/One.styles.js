import { StyleSheet, Dimensions } from "react-native";

const buildStyles = (config) =>
  StyleSheet.create({
    containerBrands: {
      flex: 1,
      width: "100%",
    },
    brand: {
      width: 430,
      padding: 20,
      alignItems: "center",
      justifyContent: "flex-start",
    },
    news: {
      width: "100%",
      padding: 20,
      alignItems: "center",
      justifyContent: "flex-start",
    },
    imageBrand: {
      width: "100%",
      height: "65%",
      resizeMode: "contain",
      borderRadius: 10,
      borderColor: "black",
      borderWidth: 0.75,
      backgroundColor: "white",
    },
    imageNews: {
      width: "100%",
      height: "100%",
      resizeMode: "contain",
      borderRadius: 1,
      backgroundColor: "white",
    },
    infoContainer: {
      marginTop: 10,
      backgroundColor: "white",
      padding: 10,
      borderRadius: 10,
      alignItems: "center",
      width: "100%",
    },
    additionalInfoContainer: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginTop: 10,
    },
    additionalInfoTextLeft: {
      flex: 1,
      color: "black",
      fontSize: 14,
      textAlign: "left",
    },
    additionalInfoTextCenter: {
      flex: 1,
      color: "black",
      fontSize: 14,
      textAlign: "center",
    },
    additionalInfoTextRight: {
      flex: 1,
      color: "black",
      fontSize: 14,
      textAlign: "right",
    },
    priceText: {
      color: "#00A36C",
    },
    bottomContainer: {
      height: "63%",
      width: "100%",
      borderBottomWidth: 0.75,
      backgroundColor: "#AEC09A",
      alignItems: "center",
    },
    footerContainer: {
      flexDirection: "row",
      height: "7%",
      borderWidth: 0.75,
      backgroundColor: "white",
      alignItems: "center",
    },
    HomeButtonLeft: {
      marginLeft: 30,
      flex: 1,
      alignItems: "flex-start",
    },
    HomeButtonCenter: {
      alignItems: "center",
    },
    HomeButtonRight: {
      flex: 1,
      marginRight: 30,
      alignItems: "flex-end",
    },
    pagination: {
      position: "absolute",
      bottom: 10,
      alignSelf: "center",
    },
    categoryContainer: {
      height: "30%",
      width: "100%",
      backgroundColor: "#EBEFB1",
      alignItems: "center",
      justifyContent: "center",
    },
    categoryRow: {
      flexDirection: "row",
      marginBottom: 20,
    },
    categoryCard: {
      width: Dimensions.get("screen").width / 2 - 30,
      height: "100%",
      backgroundColor: "#FFC9B3",
      borderRadius: 10,
      padding: 10,
      margin: 10,
      justifyContent: "center",
      alignItems: "center",
    },
    categoryText: {
      fontSize: 16,
      color: "white",
    },
    qrCode: {
      marginTop: 40,
    },
  });

export default buildStyles;
