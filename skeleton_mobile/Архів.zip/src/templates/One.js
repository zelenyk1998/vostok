import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  View,
  Image,
  TouchableOpacity,
  Text,
  FlatList,
  Pressable,
} from "react-native";
import { SliderBox } from "react-native-image-slider-box";
import { useTranslation } from "react-i18next";
import { useNavigation } from "@react-navigation/native";
import QRCode from "react-native-qrcode-svg";
import Icon from "react-native-vector-icons/FontAwesome";
import AntIcon from "react-native-vector-icons/AntDesign";

import { defaultData, defaultImages } from "./One.data";
import buildStyles from "./One.styles";
import "../localization/i18n";

const OneTemplate = ({ config, data = defaultData }) => {
  const [showQRCode, setShowQRCode] = useState(false);
  const { t } = useTranslation();
  const navigation = useNavigation();

  const openHistory = () => {
    navigation.navigate("History");
  };
  const openSettings = () => {
    navigation.navigate("Settings");
  };
  const openHome = () => {
    navigation.navigate("Home");
  };
  const openFuel = () => {
    setShowQRCode(true);
  };
  const toggleQRCode = () => {
    setShowQRCode(!showQRCode);
  };

  const styles = buildStyles(config);

  const renderItem = ({ item }) => (
    <TouchableOpacity style={styles.brand} onPress={openFuel}>
      <Image source={item.image} style={styles.imageBrand} />
      <View style={styles.infoContainer}>
        <View style={styles.additionalInfoContainer}>
          <Text style={styles.additionalInfoTextCenter}>
            {item.key} :<Text style={styles.priceText}>{item.price}</Text>
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.containerBrands}>
      <View style={styles.topContainer}></View>
      <View style={styles.bottomContainer}>
        {showQRCode ? (
          <TouchableOpacity style={styles.qrCode} onPress={toggleQRCode}>
            <QRCode
              value="https://cdn1.poz.com/135121_P10-18-012.jpg_2755ae2d-a0eb-446e-89e2-a98f4a58938e_x2.jpeg"
              size={330}
              backgroundColor="#EBEFB1"
            />
          </TouchableOpacity>
        ) : (
          <FlatList data={data} renderItem={renderItem} horizontal={true} />
        )}
      </View>
      <View style={styles.categoryContainer}>
        <View style={styles.categoryRow}>
          <TouchableOpacity style={styles.categoryCard}>
            <Icon name="shopping-basket" size={80} color="#B20000" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.categoryCard}>
            <Icon name="coffee" size={80} color="#B20000" />
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.footerContainer}>
        <Pressable style={styles.HomeButtonLeft} onPress={openHome}>
          <Icon name="home" size={30} color="#F8AE29" />
        </Pressable>
        <Pressable style={styles.HomeButtonCenter} onPress={openHistory}>
          <Icon name="history" size={30} color="#F8AE29" />
        </Pressable>
        <Pressable style={styles.HomeButtonRight} onPress={openSettings}>
          <AntIcon name="setting" color="#F8AE29" size={30} />
        </Pressable>
      </View>
    </View>
  );
};

OneTemplate.propTypes = {
  config: PropTypes.object,
  data: PropTypes.arrayOf(PropTypes.object),
};

export default OneTemplate;
