const defaultImages = [
  require("../assets/images/news1.jpg"),
  require("../assets/images/news.jpg"),
];

const defaultData = [
  {
    key: "Diesel",
    image: require("../assets/images/PetrolItem/diesel.jpg"),
    info: "Додаткова інформація 1",
    price: "52.69grn",
  },
  {
    key: "Gas",
    image: require("../assets/images/PetrolItem/gazoline.jpg"),
    info: "Додаткова інформація 2",
    price: "23.70grn",
  },
  {
    key: "Electric",
    image: require("../assets/images/PetrolItem/electrik.jpg"),
    qrImage: {
      uri: "https://stackoverflow.com/questions/46878638/how-to-clear-react-native-cache",
    },
    info: "Додаткова інформація 3",
    price: "2.60grn",
  },
];

export { defaultData, defaultImages };
