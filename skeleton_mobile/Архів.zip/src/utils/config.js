const Config = {
  merchant_name: "uber",
  axios: {
    baseUrl: "http://192.168.0.41:5001/api",
  },
};

export default Config;
