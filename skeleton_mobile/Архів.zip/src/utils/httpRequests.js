import axios from "axios";
import Config from "./config";

axios.defaults.baseURL = Config.axios.baseUrl;
axios.defaults.headers.common["Content-Type"] = "application/json";

const name = Config.merchant_name;

export const createUser = (phoneNumber) =>
  axios.post("/client/auth/register", {
    phone: phoneNumber,
    merchant: name,
  });

export const confirmCode = (internalVal, messageId) =>
  axios.post("/client/auth/confirm", {
    code: internalVal,
    secret: messageId,
    returnSecureToken: true,
  });

export const loginUser = (password, phoneNumber) =>
  axios.post("/client/auth/login", {
    password: password,
    phone: phoneNumber,
    merchant: name,
  });

export const resetPassword = (internalVal) =>
  axios.post("/client/auth/reset_password", {
    phone: internalVal,
    merchant: name,
    returnSecureToken: true,
  });

export const clientConfirmResetPassword = (authCode, messageId) =>
  axios.post("/client/auth/clientConfirmResetPassword", {
    code: authCode,
    secret: messageId,
    returnSecureToken: true,
  });

const graphQlQuery = (token, query, variables = {}) =>
  token &&
  axios
    .post(
      "/client/graphql",
      { query, variables },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )
    .then(({ data }) => (data ? data : {}));

export const getPhone = (token) =>
  graphQlQuery(token, "{self{id phone email}}");

export const getTemplate = (token) =>
  graphQlQuery(token, "{merchantTemplate{name config}}");

export const getMerchant = (token) =>
  graphQlQuery(token, "{merchant{name id}}");
