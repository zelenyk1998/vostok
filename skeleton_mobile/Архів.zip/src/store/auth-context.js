import React from "react";
import PropTypes from "prop-types";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useState } from "react";

export const AuthContext = createContext({
  token: "",
  isAuthenticated: false,
  authenticate: () => {},
  logout: () => {},
  login: () => {},
});

const AuthContextProvider = ({ children }) => {
  const [authToken, setAuthToken] = useState("");

  const authenticate = (token) => {
    if (token) {
      setAuthToken(token);
      AsyncStorage.setItem("token", token);
    }
  };

  const logout = () =>
    AsyncStorage.removeItem("token").then((token) => setAuthToken(token));
  const login = () =>
    AsyncStorage.getItem("token").then((storedToken) =>
      setAuthToken(storedToken)
    );

  const value = {
    token: authToken,
    isAuthenticated: !!authToken,
    authenticate: authenticate,
    logout: logout,
    login: login,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

AuthContextProvider.propTypes = {
  children: PropTypes.node.isRequired,
};

export default AuthContextProvider;
