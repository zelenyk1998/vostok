import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
} from "react-native";
import { useTranslation } from "react-i18next";

import { resetPassword } from "../utils/httpRequests";
import "../localization/i18n";

const RestoreScreen = ({ navigation }) => {
  const { t } = useTranslation();

  const [internalVal, setInternalVal] = useState("");

  const onChangePhone = (number) => {
    setInternalVal(number);
  };

  const onPressContinue = () => {
    resetPassword(internalVal)
      .then((response) => {
        const token = response.data.token;

        if (token) navigation.navigate("ConfimReset");
      })
      .catch(() => {
        Alert.alert(
          t("inputOTP.InvalidCodeAlert"),
          t("inputOTP.InvalidCodeAlertMessage")
        );
      });
  };

  const onPressLoginText = () => {
    navigation.navigate("Login");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.logo}>{t("restore.Logo")}</Text>
      <View style={styles.inputView}>
        <TextInput
          style={styles.inputText}
          placeholder="380 63 000 00 00"
          value={internalVal}
          maxLength={12}
          placeholderTextColor="white"
          onChangeText={onChangePhone}
          keyboardType="numeric"
        />
      </View>
      <TouchableOpacity style={styles.loginBtn} onPress={onPressContinue}>
        <Text style={styles.loginText}>{t("restore.RestoreBtn")}</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={onPressLoginText}>
        <Text style={styles.loginText}>{t("restore.LoginBtn")}</Text>
      </TouchableOpacity>
    </View>
  );
};

RestoreScreen.propTypes = {
  navigation: PropTypes.object,
};

export default RestoreScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  logo: {
    fontWeight: "bold",
    fontSize: 50,
    color: "#008080",
    marginBottom: 40,
  },
  inputView: {
    width: "80%",
    backgroundColor: "#008080",
    borderRadius: 25,
    height: 50,
    marginBottom: 20,
    justifyContent: "center",
    padding: 20,
  },
  inputText: {
    height: 50,
    color: "black",
  },
  forgot: {
    color: "black",
    fontSize: 11,
  },
  loginBtn: {
    width: "80%",
    backgroundColor: "#008080",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    marginBottom: 10,
  },
  loginText: {
    color: "black",
  },
});
