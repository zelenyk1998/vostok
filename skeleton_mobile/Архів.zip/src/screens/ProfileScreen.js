import React, { useState } from "react";
import {
  View,
  TouchableOpacity,
  Text,
  FlatList,
  StyleSheet,
  Image,
  Pressable,
} from "react-native";
import { useTranslation } from "react-i18next";
import Icon from "react-native-vector-icons/FontAwesome";
import AntIcon from "react-native-vector-icons/AntDesign";
import profileData from "../assets/data.json";

import "../localization/i18n";

const ProfileScreen = ({ navigation }) => {
  const { t, i18n } = useTranslation();
  const firstName = profileData.first_name.value;
  const lastName = profileData.last_name.value;
  const phone = profileData.phone.value;
  const email = profileData.email.value;

  const openHome = () => {
    navigation.navigate("Home");
  };
  const openHistory = () => {
    navigation.navigate("History");
  };
  const openSettings = () => {
    navigation.navigate("Settings");
  };

  return (
    <View style={styles.containerBrands}>
      <View style={styles.topContainer}>
        <View>
          <Text style={styles.pib}>
            {firstName} {lastName}
          </Text>
        </View>
        <View>
          <Text style={styles.phoneText}>{phone}</Text>
        </View>
        <View>
          <Text style={styles.emailText}>{email}</Text>
        </View>
      </View>
      <View style={styles.footerContainer}>
        <Pressable style={styles.HomeButtonLeft} onPress={openHome}>
          <Icon name="home" size={30} color="#F8AE29" />
        </Pressable>
        <Pressable style={styles.HomeButtonCenter} onPress={openHistory}>
          <Icon name="history" size={30} color="#F8AE29" />
        </Pressable>
        <Pressable style={styles.HomeButtonRight} onPress={openSettings}>
          <AntIcon name="setting" color="#F8AE29" size={30} />
        </Pressable>
      </View>
    </View>
  );
};

export default ProfileScreen;

const styles = StyleSheet.create({
  containerBrands: {
    flex: 1,
  },
  topContainer: {
    height: "93%",
    width: "100%",
    backgroundColor: "#FFE4B5",
    justifyContent: "center",
    borderTopWidth: 0.6,
    borderBottomWidth: 0.3,
  },
  pib: {
    fontSize: 30,
    color: "#058240",
    margin: 20,
  },
  phoneText: {
    fontSize: 30,
    color: "#058240",
    margin: 20,
  },
  emailText: {
    fontSize: 30,
    color: "#058240",
    margin: 20,
  },
  footerContainer: {
    flexDirection: "row",
    height: "7%",
    width: "100%",
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  HomeButtonLeft: {
    marginLeft: 30,
    flex: 1,
    alignItems: "flex-start",
  },
  HomeButtonCenter: {
    alignItems: "center",
  },
  HomeButtonRight: {
    flex: 1,
    marginRight: 30,
    alignItems: "flex-end",
  },
});
