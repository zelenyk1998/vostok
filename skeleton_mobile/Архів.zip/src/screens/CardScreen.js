import React from "react";
import { StyleSheet, View, Text, Pressable, Image } from "react-native";
import Icon from "react-native-vector-icons/FontAwesome";
import AntIcon from "react-native-vector-icons/AntDesign";
import { useTranslation } from "react-i18next";

import "../localization/i18n";

const CardScreen = ({ navigation }) => {
	const { t, i18n } = useTranslation();
	const openHome = () => {
		navigation.navigate("Home");
	};
	const openHistory = () => {
		navigation.navigate("History");
	};
	const openSettings = () => {
		navigation.navigate("Settings");
	};
	return (
		<View style={styles.container}>
			<View style={styles.topContainer}>
				<View style={styles.containerCard}>
					<View style={styles.circles}>
						<View style={styles.circle_1}></View>
						<View style={styles.circle_2}></View>
					</View>
					<View style={styles.card}>
						<View style={styles.visa_logo}>
							<Image
								source={{
									uri: "https://point.autoua.net/media/cache5/1b/4f/1b4f7e25b77479c3b6335daa5a20faee.jpg",
								}}
								style={styles.visa_logo_img}
							/>
						</View>
						<View style={styles.visa_crinfo}>
							<Text>02/12</Text>
							<Text>Nikhil Bobade</Text>
						</View>
					</View>
				</View>
			</View>
			<View style={styles.footerContainer}>
				<Pressable style={styles.HomeButtonLeft} onPress={openHome}>
					<Icon name="home" size={30} color="#900" />
				</Pressable>
				<Pressable
					style={styles.HomeButtonCenter}
					onPress={openHistory}
				>
					<Icon name="history" size={30} color="#900" />
				</Pressable>
				<Pressable
					style={styles.HomeButtonRight}
					onPress={openSettings}
				>
					<AntIcon name="setting" color="#900" size={30} />
				</Pressable>
			</View>
		</View>
	);
};

export default CardScreen;

const styles = StyleSheet.create({
	container: {
		flex: 1,
		width: "100%",
	},
	topContainer: {
		height: "93%",
		width: "100%",
		backgroundColor: "#FFE4B5",
		justifyContent: "center",
		alignItems: "center",
		borderTopWidth: 0.6,
		borderBottomWidth: 0.3,
	},
	containerCard: {
		flex: 1,
		justifyContent: "center",
		alignItems: "center",
		fontFamily: "Rubik, sans-serif",
	},
	circles: {
		position: "absolute",
		height: 270,
		width: 450,
		top: "50%",
		left: "50%",
	},
	circle_1: {
		position: "absolute",
		top: -50,
		borderRadius: 100,
		left: 10,
		height: 160,
		width: 160,
	},
	circle_2: {
		position: "absolute",
		borderRadius: 100,
		right: 40,
		top: 80,
		opacity: 0.8,
		height: 160,
		width: 160,
	},
	card: {
		width: 380,
		height: 230,
		borderWidth: 2,
		borderColor: "rgba(255, 255, 255, 0.2)",
		backgroundColor: "white",
		borderRadius: 10,
		overflow: "hidden",
		position: "relative",
	},
	visa_logo: {
		position: "absolute",
		resizeMode: "contain",
		top: 10,
		right: 10,
		padding: 10,
	},
	visa_logo_img: {
		width: 170,
		height: 120,
	},
	visa_info: {
		padding: 10,
		marginVertical: 30,
	},
	visa_info_img: {
		width: 60,
		height: 45,
	},
	visa_info_p: {
		fontSize: 22,
		paddingVertical: 10,
		color: "#ffffff",
	},
	visa_crinfo: {
		flexDirection: "row",
		justifyContent: "space-between",
		paddingHorizontal: 10,
		color: "#ffffff",
	},
	text: {
		color: "white",
		fontSize: 30,
	},
	footerContainer: {
		flexDirection: "row",
		height: "7%",
		borderWidth: 0.75,
		backgroundColor: "white",
		alignItems: "center",
	},
	HomeButtonLeft: {
		marginLeft: 30,
		flex: 1,
		alignItems: "flex-start",
	},
	HomeButtonCenter: {
		alignItems: "center",
	},
	HomeButtonRight: {
		flex: 1,
		marginRight: 30,
		alignItems: "flex-end",
	},
});
