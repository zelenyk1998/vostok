import React, { useState, useEffect, useContext } from "react";
import PropTypes from "prop-types";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
} from "react-native";
import { useTranslation } from "react-i18next";

import { createUser, confirmCode } from "../utils/httpRequests";
import { AuthContext } from "../store/auth-context";
import "../localization/i18n";

const InputOTPScreen = ({ navigation, route }) => {
  const { t } = useTranslation();

  let clockCall = null;

  const formatTime = (d) => {
    const minutes = Math.floor(d / 60);
    const seconds = d % 60;
    const timeString =
      minutes.toString() + ":" + seconds.toString().padStart(2, "0");

    return timeString;
  };

  const [internalVal, setInternalVal] = useState("");
  const [enableResend, setEnableResend] = useState(false);
  const [countdown, setCountdown] = useState(300);
  const authCtx = useContext(AuthContext);

  useEffect(() => {
    clockCall = setInterval(() => {
      decrementClock();
    }, 1000);

    return () => {
      clearInterval(clockCall);
    };
  }, clockCall);

  const decrementClock = () => {
    if (countdown === 0) {
      setEnableResend(true);
      clearInterval(clockCall);
    } else {
      setCountdown(countdown - 1);
    }
  };

  const onChangeText = (val) => {
    setInternalVal(val);
  };

  const { messageId, phoneNumber } = route.params;

  const onConfirmCode = () => {
    confirmCode(internalVal, messageId)
      .then((response) => {
        const token = response.data.token;

        authCtx.authenticate(token);
        if (token) navigation.replace("Home");
      })
      .catch(() => {
        Alert.alert(
          t("inputOTP.InvalidCodeAlert"),
          t("inputOTP.InvalidCodeAlertMessage")
        );
      });
  };

  const onResendOTP = () => {
    if (enableResend) {
      setCountdown(300);
      setEnableResend(false);
      clearInterval(clockCall);
      clockCall = setInterval(() => {
        decrementClock();
      }, 1000);
      createUser(phoneNumber);
    }
  };

  const onChangeNumber = () => {
    navigation.navigate("Authentication");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.textTitle}>{t("inputOTP.Title") + phoneNumber}</Text>
      <Text style={styles.textTitleInput}>{t("inputOTP.TitleInput")}</Text>
      <Text style={styles.logo}>{t("inputOTP.Logo")}</Text>
      <View style={styles.inputView}>
        <TextInput
          style={styles.inputText}
          onChangeText={onChangeText}
          placeholder={t("inputOTP.InputPlaceholder")}
          placeholderTextColor="white"
          value={internalVal}
          keyboardType="numeric"
        />
      </View>
      <TouchableOpacity onPress={onChangeNumber}>
        <Text style={styles.forgot}>{t("inputOTP.ChangeNumberBtn")}</Text>
        <Text
          onPress={onResendOTP}
          style={[
            styles.textResend,
            { color: enableResend ? "black" : "#008080" },
          ]}
        >
          {t("inputOTP.ResendBtn")} ({formatTime(countdown)})
        </Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.loginBtn} onPress={onConfirmCode}>
        <Text style={styles.loginText}>{t("inputOTP.ConfirnBtn")}</Text>
      </TouchableOpacity>
    </View>
  );
};

InputOTPScreen.propTypes = {
  navigation: PropTypes.object,
  route: PropTypes.object,
};

export default InputOTPScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  logo: {
    fontWeight: "bold",
    fontSize: 50,
    color: "#008080",
    marginBottom: 40,
  },
  inputView: {
    width: "80%",
    backgroundColor: "#008080",
    borderRadius: 25,
    height: 50,
    marginBottom: 20,
    justifyContent: "center",
    padding: 20,
  },
  inputText: {
    height: 50,
    color: "white",
  },
  forgot: {
    color: "black",
    fontSize: 11,
    marginBottom: 20,
  },
  loginBtn: {
    width: "80%",
    backgroundColor: "#008080",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    marginBottom: 10,
  },
  loginText: {
    color: "white",
  },
  bottomView: {
    flexDirection: "row",
    flex: 1,
    position: "absolute",
    bottom: 0,
    marginBottom: 50,
    alignItems: "flex-end",
  },
  btnResend: {
    width: 220,
    height: 50,
    borderRadius: 10,
    alignItems: "flex-end",
    justifyContent: "center",
    marginRight: 20,
  },
  textResend: {
    alignItems: "center",
    fontSize: 15,
    color: "black",
  },
  btnChangeNumber: {
    width: 150,
    height: 50,
    borderRadius: 10,
    alignItems: "flex-start",
    justifyContent: "center",
    marginLeft: 20,
  },
  textChange: {
    color: "black",
  },
  textTitle: {
    marginTop: 50,
    marginBottom: 15,
    fontSize: 16,
    color: "black",
    justifyContent: "flex-start",
  },
  textTitleInput: {
    fontSize: 16,
    marginBottom: 15,
    marginTop: 30,
    color: "black",
  },
});
