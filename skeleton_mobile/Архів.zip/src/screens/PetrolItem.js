import React from "react";
import { StyleSheet, View, Image, FlatList } from "react-native";

import "../localization/i18n";

const PetrolItem = () => (
  <View style={styles.containerBrands}>
    <FlatList
      data={[
        { key: "socar", image: require("../assets/images/Petrol/socar.png") },
        { key: "okko", image: require("../assets/images/Petrol/okko.png") },
        { key: "brsm", image: require("../assets/images/Petrol/brsm.jpeg") },
        {
          key: "ukrpet",
          image: require("../assets/images/Petrol/ukrpetrol.png"),
        },
        { key: "wog2", image: require("../assets/images/Petrol/wog.png") },
        {
          key: "shell2",
          image: require("../assets/images/Petrol/shell.png"),
        },
        { key: "amic", image: require("../assets/images/Petrol/amic.jpg") },
        { key: "avias", image: require("../assets/images/Petrol/avias.png") },
      ]}
      renderItem={({ item }) => (
        <View style={styles.brand}>
          <Image source={item.image} style={styles.imageBrand} />
        </View>
      )}
      numColumns={2}
      contentContainerStyle={styles.gridItem}
    />
  </View>
);

export default PetrolItem;

const styles = StyleSheet.create({
  containerBrands: {
    flex: 1,
    backgroundColor: "#003f5c",
  },
  gridItem: {
    flexDirection: "column",
  },
  row: {
    flexDirection: "row",
  },
  brand: {
    flex: 1,
    padding: 20,
    aspectRatio: 1,
    maxWidth: "50%",
  },
  button: {
    flex: 1,
  },
  buttonPressed: {
    opacity: 0.5,
  },
  title: {
    fontWeight: "bold",
    fontSize: 18,
    color: "white",
  },
  imageBrand: {
    width: 170,
    height: 150,
    resizeMode: "contain", // Додаємо цей стиль
    borderRadius: 10,
    borderColor: "black",
    backgroundColor: "white",
  },
});
