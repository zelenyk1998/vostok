import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
} from "react-native";
import PropTypes from "prop-types";
import React, { useState, useContext } from "react";
import { useTranslation } from "react-i18next";
import { AuthContext } from "../store/auth-context";

import { loginUser } from "../utils/httpRequests";
import "../localization/i18n";

const LoginScreenDay = ({ navigation }) => {
  const { t } = useTranslation();

  const [phoneNumber, setPhoneNumber] = useState("");
  const [password, setPassword] = useState("");
  const [isLogin, setIsLogin] = useState(false);
  const [secureText, setSecureText] = useState(true);
  const authCtx = useContext(AuthContext);

  const onPressLogin = () => {
    if (password.trim() === "" || phoneNumber.length < 12) {
      Alert.alert(t("login.Error"), t("login.EnteredValNumer"));

      return;
    }

    setIsLogin(true);

    loginUser(password, phoneNumber)
      .then((response) => {
        const token = response.data.token;

        authCtx.authenticate(token);
        if (token && isLogin) {
          navigation.replace("Home");
        }
        setIsLogin(false);
      })
      .catch((error) => {
        Alert.alert(t("login.Error"), t("login.ErrorLogin"));

        return Promise.reject(error);
      });
  };
  console.log(onPressLogin);

  const onChangeSecure = () => {
    setSecureText((prevValue) => !prevValue);
  };

  const onPressRegister = () => {
    navigation.navigate("Authentication");
  };

  const onPressRestore = () => {
    navigation.navigate("Restore");
  };

  const onChangePhone = (number) => {
    setPhoneNumber(number);
  };

  const onChangePassword = (password) => {
    setPassword(password);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.logo}>{t("login.Logo")}</Text>
      <View style={styles.inputView}>
        <TextInput
          style={styles.inputText}
          placeholder="380 63 000 00 00"
          value={phoneNumber}
          maxLength={12}
          placeholderTextColor="#AAFF00"
          onChangeText={onChangePhone}
          keyboardType="numeric"
        />
      </View>
      <View style={styles.inputView}>
        <TextInput
          secureTextEntry={secureText}
          style={styles.inputText}
          placeholder={t("login.password")}
          placeholderTextColor="#AAFF00"
          onChangeText={onChangePassword}
          keyboardType="default"
          onSubmitEditing={onPressLogin}
        />
      </View>
      <View style={styles.btnContainer}>
        <TouchableOpacity onPress={onPressRestore} style={styles.forgotPass}>
          <Text style={styles.forgot}>{t("login.restore")}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={onChangeSecure} style={styles.showPassword}>
          <Text style={styles.showPass}>{t("login.showPass")}</Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.loginBtn} onPress={onPressLogin}>
        <Text style={styles.loginText}>{t("login.btnlog")}</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={onPressRegister} style={styles.registerBtn}>
        <Text style={styles.registerText}>{t("login.alrreg")}</Text>
      </TouchableOpacity>
    </View>
  );
};

LoginScreenDay.propTypes = {
  navigation: PropTypes.object,
};

export default LoginScreenDay;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#988558",
    alignItems: "center",
    justifyContent: "center",
  },
  logo: {
    fontWeight: "bold",
    fontSize: 50,
    color: "#AAFF00",
    marginBottom: 40,
  },
  inputView: {
    width: "80%",
    backgroundColor: "#FF10F0",
    borderRadius: 3,
    height: 50,
    marginBottom: 2,
    justifyContent: "center",
    padding: 20,
    borderColor: "#00FF7F",
    borderWidth: 0.75,
  },
  inputText: {
    height: 50,
    color: "#8B0000",
  },
  forgot: {
    color: "white",
    fontSize: 11,
    paddingTop: 2,
    alignItems: "center",
  },
  showPass: {
    color: "black",
    fontSize: 11,
    paddingTop: 2,
  },
  loginBtn: {
    width: "80%",
    backgroundColor: "#FF10F0",
    borderRadius: 3,
    height: 30,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    marginBottom: 3,
    borderColor: "#00FF7F",
    borderWidth: 0.75,
  },
  loginText: {
    color: "#AAFF00",
  },
  registerText: {
    color: "#AAFF00",
  },
  showPassword: {
    height: 20,
    width: 100,
    marginTop: 5,
    marginLeft: 10,
    alignItems: "center",
  },
  forgotPass: {
    height: 20,
    width: 120,
    marginTop: 5,
    marginRight: 25,
    alignItems: "center",
  },
  btnContainer: {
    flexDirection: "row",
  },
  registerBtn: {
    width: "80%",
    borderRadius: 3,
    borderColor: "#00FF7F",
    borderWidth: 0.75,
    height: 30,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 1,
    marginBottom: 10,
  },
});
