import React, { useContext, useState } from "react";
import PropTypes from "prop-types";
import AsyncStorage from "@react-native-async-storage/async-storage";
import OneTemplate from "../templates/One.js";

const HomeScreen = ({ navigation }) => {
  return <OneTemplate />;
};

HomeScreen.propTypes = {
  navigation: PropTypes.object,
};

export default HomeScreen;
