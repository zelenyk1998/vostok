import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
} from "react-native";
import { useTranslation } from "react-i18next";

import { createUser } from "../utils/httpRequests";
import "../localization/i18n";

const AuthenticationScreen = ({ navigation }) => {
  const { t } = useTranslation();

  const [phoneNumber, setPhoneNumber] = useState("");

  const onChangePhone = (number) => {
    setPhoneNumber(number);
  };

  const onPressContinue = () => {
    if (phoneNumber.length === 12) {
      createUser(phoneNumber)
        .then((res) => {
          const messageId = res.data.secret;

          if (messageId) {
            navigation.navigate("InputOTP", { messageId, phoneNumber });
          }
        })
        .catch(() =>
          Alert.alert(t("auth.RegisterAlert"), t("auth.RegisterAlertMessage"))
        );
    } else {
      Alert.alert(
        t("auth.InvalidPhoneAlert"),
        t("auth.InvalidPhoneAlertMessage")
      );
    }
  };

  const onPressText = () => {
    navigation.navigate("Login");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.logo}>{t("auth.Logo")}</Text>
      <View style={styles.inputView}>
        <TextInput
          style={styles.inputText}
          placeholder="380 63 000 00 00"
          value={phoneNumber}
          maxLength={12}
          placeholderTextColor="white"
          onChangeText={onChangePhone}
          keyboardType="numeric"
        />
      </View>
      <TouchableOpacity style={styles.loginBtn} onPress={onPressContinue}>
        <Text style={styles.loginText}>{t("auth.ContinueBtn")}</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={onPressText}>
        <Text style={styles.registerText}>{t("auth.login")}</Text>
      </TouchableOpacity>
    </View>
  );
};

AuthenticationScreen.propTypes = {
  navigation: PropTypes.object,
};

export default AuthenticationScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#white",
    alignItems: "center",
    justifyContent: "center",
  },
  logo: {
    fontWeight: "bold",
    fontSize: 50,
    color: "#008080",
    marginBottom: 40,
  },
  inputView: {
    width: "80%",
    backgroundColor: "#008080",
    borderRadius: 25,
    height: 50,
    marginBottom: 20,
    justifyContent: "center",
    padding: 20,
  },
  inputText: {
    height: 50,
    color: "white",
  },
  loginBtn: {
    width: "80%",
    backgroundColor: "#008080",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    marginBottom: 10,
  },
  loginText: {
    color: "white",
  },
  registerText: {
    color: "black",
  },
});
