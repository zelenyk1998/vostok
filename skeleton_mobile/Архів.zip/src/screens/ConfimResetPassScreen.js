import React, { useState, useEffect, useContext } from "react";
import PropTypes from "prop-types";

import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
} from "react-native";
import { useTranslation } from "react-i18next";

import { clientConfirmResetPassword } from "../utils/httpRequests";
import { AuthContext } from "../store/auth-context";
import "../localization/i18n";

const ConfimResetPassScreen = ({ navigation, route }) => {
  const { t } = useTranslation();
  let clockCall = null;

  const formatTime = (d) => {
    const minutes = Math.floor(d / 60);
    const seconds = d % 60;
    const timeString =
      minutes.toString() + ":" + seconds.toString().padStart(2, "0");

    return timeString;
  };

  const [authCode, setAuthCode] = useState("");
  const [enableResend, setEnableResend] = useState(false);
  const [countdown, setCountdown] = useState(300);

  const authCtx = useContext(AuthContext);

  useEffect(() => {
    clockCall = setInterval(() => {
      decrementClock();
    }, 1000);

    return () => {
      clearInterval(clockCall);
    };
  }, clockCall);

  const decrementClock = () => {
    if (countdown === 0) {
      setEnableResend(true);
      clearInterval(clockCall);
    } else {
      setCountdown(countdown - 1);
    }
  };

  const onChangeText = (val) => {
    setAuthCode(val);
  };

  const { messageId } = route.params;

  const onConfirmCode = () => {
    clientConfirmResetPassword(authCode, messageId)
      .then((response) => {
        const token = response.data.token;

        authCtx.authenticate(token);
        if (token) navigation.replace("Home");
      })
      .catch(() => {
        Alert.alert(
          t("inputOTP.InvalidCodeAlert"),
          t("inputOTP.InvalidCodeAlertMessage")
        );
      });
  };

  const onResendOTP = () => {
    if (enableResend) {
      setCountdown(300);
      setEnableResend(false);
      clearInterval(clockCall);
      clockCall = setInterval(() => {
        decrementClock();
      }, 1000);
    }
  };

  const onChangeNumber = () => {
    navigation.navigate("Restore");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.textTitle}>{t("inputOTP.Title")}</Text>
      <Text style={styles.textTitleInput}>{t("inputOTP.TitleInput")}</Text>
      <Text style={styles.logo}>{t("inputOTP.Logo")}</Text>
      <View style={styles.inputView}>
        <TextInput
          style={styles.inputText}
          onChangeText={onChangeText}
          placeholder={t("inputOTP.InputPlaceholder")}
          value={authCode}
          keyboardType="numeric"
        />
      </View>
      <TouchableOpacity onPress={onChangeNumber}>
        <Text style={styles.forgot}>{t("inputOTP.ChangeNumberBtn")}</Text>
        <Text
          onPress={onResendOTP}
          style={[styles.textResend, { color: enableResend ? "white" : "red" }]}
        >
          {t("inputOTP.ResendBtn")} ({formatTime(countdown)})
        </Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.loginBtn} onPress={onConfirmCode}>
        <Text style={styles.loginText}>{t("inputOTP.ConfirnBtn")}</Text>
      </TouchableOpacity>
    </View>
  );
};

ConfimResetPassScreen.propTypes = {
  navigation: PropTypes.object,
  route: PropTypes.object,
};

export default ConfimResetPassScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#003f5c",
    alignItems: "center",
    justifyContent: "center",
  },
  logo: {
    fontWeight: "bold",
    fontSize: 50,
    color: "#C70039",
    marginBottom: 40,
  },
  inputView: {
    width: "80%",
    backgroundColor: "#465881",
    borderRadius: 25,
    height: 50,
    marginBottom: 20,
    justifyContent: "center",
    padding: 20,
  },
  inputText: {
    height: 50,
    color: "white",
  },
  forgot: {
    color: "white",
    fontSize: 11,
    marginBottom: 20,
  },
  loginBtn: {
    width: "80%",
    backgroundColor: "#C70039",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    marginBottom: 10,
  },
  loginText: {
    color: "white",
  },
  bottomView: {
    flexDirection: "row",
    flex: 1,
    position: "absolute",
    bottom: 0,
    marginBottom: 50,
    alignItems: "flex-end",
  },
  btnResend: {
    width: 220,
    height: 50,
    borderRadius: 10,
    alignItems: "flex-end",
    justifyContent: "center",
    marginRight: 20,
  },
  textResend: {
    alignItems: "center",
    fontSize: 15,
    color: "white",
  },
  btnChangeNumber: {
    width: 150,
    height: 50,
    borderRadius: 10,
    alignItems: "flex-start",
    justifyContent: "center",
    marginLeft: 20,
  },
  textChange: {
    color: "white",
  },
  textTitle: {
    marginTop: 50,
    marginBottom: 15,
    fontSize: 16,
    color: "white",
    justifyContent: "flex-start",
  },
  textTitleInput: {
    fontSize: 16,
    marginBottom: 15,
    marginTop: 30,
    color: "white",
  },
});
