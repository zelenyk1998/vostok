import React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import Icon from "react-native-vector-icons/FontAwesome";
import AntIcon from "react-native-vector-icons/AntDesign";
import { useTranslation } from "react-i18next";

import "../localization/i18n";

const HistoryScreen = ({ navigation }) => {
	const { t, i18n } = useTranslation();
	const openHome = () => {
		navigation.navigate("Home");
	};
	const openHistory = () => {
		navigation.navigate("History");
	};
	const openSettings = () => {
		navigation.navigate("Settings");
	};
	return (
		<View style={styles.container}>
			<View style={styles.containerBrands}>
				<Text style={styles.text}>History Page</Text>
			</View>
			<View style={styles.footerContainer}>
				<Pressable style={styles.HomeButtonLeft} onPress={openHome}>
					<Icon name="home" size={30} color="#900" />
				</Pressable>
				<Pressable
					style={styles.HomeButtonCenter}
					onPress={openHistory}
				>
					<Icon name="history" size={30} color="#900" />
				</Pressable>
				<Pressable
					style={styles.HomeButtonRight}
					onPress={openSettings}
				>
					<AntIcon name="setting" color="#900" size={30} />
				</Pressable>
			</View>
		</View>
	);
};
export default HistoryScreen;

const styles = StyleSheet.create({
	container: {
		flex: 1,
		width: "100%",
	},
	containerBrands: {
		backgroundColor: "#8B0000",
		alignItems: "center",
		justifyContent: "center",
		height: "93%",
	},
	text: {
		color: "white",
		fontSize: 30,
	},
	footerContainer: {
		flexDirection: "row",
		height: "7%",
		borderWidth: 0.75,
		backgroundColor: "white",
		alignItems: "center",
	},
	HomeButtonLeft: {
		marginLeft: 30,
		flex: 1,
		alignItems: "flex-start",
	},
	HomeButtonCenter: {
		alignItems: "center",
	},
	HomeButtonRight: {
		flex: 1,
		marginRight: 30,
		alignItems: "flex-end",
	},
});
